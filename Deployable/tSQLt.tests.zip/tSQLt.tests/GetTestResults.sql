:XML ON
EXEC [tSQLt].[XmlResultFormatter];

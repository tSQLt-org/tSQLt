EXEC tSQLt.InstallExternalAccessKey;


GO
:OUT NUL:
GO
USE [$(DbName)];
GO
:OUT STDOUT
GO
$(ExecuteStatement)
GO
